object Categoria extends Enumeration {
  type Categoria = Value
  val ciencia, literatura, filosofia = Value
}


