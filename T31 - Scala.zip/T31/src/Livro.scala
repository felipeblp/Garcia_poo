
class Livro(var nome: String, var autor: String, var anoPublicacao: Int) {
  def getNome: String = nome

  def getAutor: String = autor

  def getAnoPublicacao: Int = anoPublicacao

  //metodo acrescentado para mostrar dados do livro
  def mostrarInfoLivro(): Unit = {
    System.out.println("Título: " + this.getNome)
    System.out.println("Autor do livro: " + this.getAutor)
    System.out.println("Publicado em: " + this.getAnoPublicacao)
    System.out.println(" ")
  }
}


}
