import scala.collection.mutable.ListBuffer

class Biblioteca(var nome: String, val estantes: List[Estante]) {
  this.estantes = estantes
  private var estantes = new List[Estante]

  def getNome: String = nome

  def getEstantes: List[Estante] = estantes

  def inserirEstante(estante: Estante): Unit = {
    if (estante != null) estantes.add(estante)
  }

  def listarFilosofia(): Unit = {

    for (e <- estantes) {
      if (e.getCategoria.toString eq "Filosofia") {
        System.out.println("//////////////Filosofia////////////////")

        for (l <- e.getLivros) {
          l.mostrarInfoLivro()
        }
        System.out.println("//////////////Filosofia////////////////")
      }
    }
  }

  def contarCiencia(): Unit = {
    var contciencia = 0

    for (e <- estantes) {
      if (e.getCategoria.toString eq "Ciencia") {

        for (l <- e.getLivros) {
          contciencia += 1
        }
      }
    }
  }

  def listarTudo(): Unit = {

    for (e <- estantes) {
      e.getCategoria.toString match {
        case "Ciencia" =>
          System.out.println("///////////Ciencia////////////")

          for (l <- e.getLivros) {
            l.mostrarInfoLivro()
          }
          System.out.println("///////////Ciencia////////////")

        case "Literatura" =>
          System.out.println("///////////Literatura////////////")

          for (l <- e.getLivros) {
            l.mostrarInfoLivro()
          }
          System.out.println("///////////Literatura////////////")

        case "Filosofia" =>
          System.out.println("///////////Filosofia////////////")

          for (l <- e.getLivros) {
            l.mostrarInfoLivro()
          }
          System.out.println("///////////Filosofia////////////")

      }
    }
  }

  def listarAutores(cat: Categoria.type): Unit = {

    for (e <- estantes) {
      cat.toString match {
        case "Ciencia" =>
          System.out.println("///////////Ciencia////////////")

          for (l <- e.getLivros) {
            System.out.println("Autor: " + l.getAutor)
          }
          System.out.println("///////////Ciencia////////////")

        case "Literatura" =>
          System.out.println("///////////Literatura////////////")

          for (l <- e.getLivros) {
            System.out.println("Autor: " + l.getAutor)
          }
          System.out.println("///////////Literatura////////////")

        case "Filosofia" =>
          System.out.println("///////////Filosofia////////////")

          for (l <- e.getLivros) {
            System.out.println("Autor: " + l.getAutor)
          }
          System.out.println("///////////Filosofia////////////")

      }
    }
  }

  def listarLivros(cat: Categoria.type): Unit = {

    for (e <- estantes) {
      cat.toString match {
        case "Ciencia" =>
          System.out.println("///////////Ciencia////////////")

          for (l <- e.getLivros) {
            System.out.println("Nome: " + l.getNome)
          }
          System.out.println("///////////Ciencia////////////")

        case "Literatura" =>
          System.out.println("///////////Literatura////////////")

          for (l <- e.getLivros) {
            System.out.println("Nome: " + l.getNome)
          }
          System.out.println("///////////Literatura////////////")

        case "Filosofia" =>
          System.out.println("///////////Filosofia////////////")

          for (l <- e.getLivros) {
            System.out.println("Nome: " + l.getNome)
          }
          System.out.println("///////////Filosofia////////////")

      }
    }
  }
}


}
