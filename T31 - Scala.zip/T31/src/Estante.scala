import scala.collection.mutable.ListBuffer

class Estante(var nome: String, var cat: Categoria.type, val livros: List[Livro]) {
  this.livros = livros
  private var livros = new List[Livro]

  def getNome: String = nome

  def getLivros: List[Livro] = livros

  def getCategoria: Categoria.type = cat

  def inserirLivro(livro: Livro): Unit = {
    livros.add(livro)
  }

  def removerLivro(livro: Livro): Unit = {
    livros.remove(livro)
    System.out.println(livro.getNome + "Livro removido")
  }

  //metodo acrescentado para mostrar dados da estante
  def mostrarInfoEstante(): Unit = {
    System.out.println("Nome da Estante: " + nome)
    System.out.println("Categoria: " + cat)
    System.out.println("Livros na Estante: " + livros)
    System.out.println(" ")

    for (l <- livros) {
      l.mostrarInfoLivro()
    }
  }
}

}
