import scala.collection.mutable.ListBuffer

object Principal {
  def main(args: Array[String]): Unit = {
    val estantes = new List[Estante]
    val livros = new List[Livro]
    val b = new Biblioteca("teste", estantes)
    val e = null
    var c = null
    var nome = null
    var autor = null
    var ano = 0
    val cont = 9
    do {
      val s = new Scanner(System.in)
      System.out.println("Olá usuario, o que deseja fazer? ")
      System.out.println("1 - Inserir Livro na Estante: ")
      System.out.println("2 - Remover Livro da Estante : ")
      System.out.println("3 - Adicionar a Estante a biblioteca: ")
      System.out.println("4 - Listar Categoria Filosofia: ")
      System.out.println("5 - Contar Livros categoria ciencia: ")
      System.out.println("6 - Listar Autores por categoria: ")
      System.out.println("7 - Listar todos os livros de todas as estantes: ")
      System.out.println("0 - Sair: ")
      val op = s.nextInt
      op match {
        case 1 =>
          System.out.println("Digite a categoria do livro: ")
          System.out.println("1-Ciencias: ")
          System.out.println("2-Literatura: ")
          System.out.println("3-Filosofia: ")
          val op2 = s.nextInt
          op2 match {
            case 1 =>
              c = Categoria.ciencia
              val est = new Estante(nome, c, livros)
              System.out.println("Digite o nome do livro: ")
              nome = s.nextLine
              System.out.println("Digite o nome do autor: ")
              autor = s.nextLine
              System.out.println("Digite o ano de publicacao: ")
              ano = s.nextInt
              val l = new Livro(nome, autor, ano)

            case 2 =>
              c = Categoria.literatura
              System.out.println("Digite o nome do livro: ")
              nome = s.nextLine
              System.out.println("Digite o nome do autor: ")
              autor = s.nextLine
              System.out.println("Digite o ano de publicacao: ")
              ano = s.nextInt
              val l1 = new Livro(nome, autor, ano)

            case 3 =>
              c = Categoria.filosofia
              System.out.println("Digite o nome do livro: ")
              nome = s.nextLine
              System.out.println("Digite o nome do autor: ")
              autor = s.nextLine
              System.out.println("Digite o ano de publicacao: ")
              ano = s.nextInt
              val l2 = new Livro(nome, autor, ano)

          }

        case 2 =>
          System.out.println("Remover Livro: ")
          e.removerLivro(livros.getNome)

        case 3 =>
          System.out.println("Adicionar Estante: ")
          b.inserirEstante(estantes.getNome)

        case 4 =>
          System.out.println("Listando categoria Filosofia: ")
          b.listarFilosofia()

        case 5 =>
          System.out.println("Contando livroscategoria Ciencia: ")
          b.contarCiencia()

        case 6 =>
          System.out.println("Listando autores por categoria: ")
          b.listarAutores(Categoria.filosofia)
          b.listarAutores(Categoria.ciencia)
          b.listarAutores(Categoria.literatura)

        case 7 =>
          System.out.println("Listando tudo: ")
          b.listarTudo()

        case 0 =>
          System.out.println("Ate Logo!")

        case _ =>
          System.out.println("Opção inválida.")

      }
    } while ( {
      cont != 0
    })
  }
}

