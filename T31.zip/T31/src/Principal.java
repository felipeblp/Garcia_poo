import java.util.Scanner;

public class Principal {

	public static void menu() {
		System.out.println("Ola usuario, o que deseja fazer?");
	     System.out.println("");
	     System.out.println("1- Adicionar Livro � estante");
	     System.out.println("2- Remover Livro da estante");
	     System.out.println("3- Adicionar Estante � Biblioteca");
	     System.out.println("4- Listar Categoria Filosofia");
	     System.out.println("5- Contar Livros Categoria Ciencia");
	     System.out.println("6- Listar Autores por categoria");
	     System.out.println("7- Listar todos os livros de todas as estantes");
	     System.out.println("0- Sair");
	     System.out.println("");
	     System.out.print("Digite sua op��o: ");
	}

	public static void main(String[] args) {
		 
		
	     Biblioteca b = new Biblioteca("Library");
	    
	     Estante e1 = new Estante("Estante1",Categoria.Ciencia);
	     Estante e2 = new Estante("Estante2",Categoria.Filosofia);
	     Estante e3 = new Estante("Estante3",Categoria.Literatura);
	     

         Livro livro1 = new Livro("A volta dos que n�o foram","Zohan","2000");
       	 Livro livro2 = new Livro("Haskell eh o futuro", "Zordon", "2017");
     	 Livro livro3 = new Livro("Esquece C++", "Nemesis","2015");
	     
     	int opcao;
		Scanner entrada = new Scanner(System.in);

	            do {   
	            	menu();
	            	opcao = entrada.nextInt();
	            switch(opcao) {	
	                case 1:
	                	System.out.println("Adicionar Livro: ");
	                	e1.inserirLivro(livro1);
	                	e2.inserirLivro(livro2);
	                	e3.inserirLivro(livro3);
	                        break;
	                case 2:
	                	System.out.println("Remover Livro: ");
	                	e1.removerLivro(null);
	                	
	                        break;                
	                case 3:
	                	System.out.println("Adicionar Estante: ");
	                	b.inserirEstante(null);
	                		break;
	                case 4:
	                	System.out.println("Listando categoria Filosofia: ");
	                		break;
	                case 5:
	                	System.out.println("Contando livroscategoria Ciencia: ");
	                	 e1.contarCiencia();
	                        break;
	                case 6: 
	                	System.out.println("Listando autores por categoria: ");
	                		break;
	                case 7: 
	                	System.out.println("Listando tudo: ");
	                	b.listarTudo();
                			break;
	                case 0:
	                		System.out.println("Ate Logo!");
	                		break;
	                 
	              default: 
	                       System.out.println("Op��o inv�lida.");
	                       break; }
	                      
	            }
	            
	            while(opcao!=0); 
	            
	
	}

}
