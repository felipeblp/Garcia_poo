
public class Livro {

	private String nome,autor,anoPublicacao;

	public String getNome() {
		return nome;
	}

	public String getAutor() {
		return autor;
	}

	public String getAnoPublicacao() {
		return anoPublicacao;
	}

	public Livro(String nome, String autor, String anoPublicacao) {
		this.nome = nome;
		this.autor = autor;
		this.anoPublicacao = anoPublicacao;
	}
	
//metodo acrescentado para mostrar dados do livro
	
	public void mostrarInfoLivro() {
		System.out.println("T�tulo: " + nome);
		System.out.println("Autor do livro: " + autor);
		System.out.println("Publicado em: " + anoPublicacao);
		System.out.println(" ");
	}
}
