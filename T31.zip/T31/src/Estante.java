import java.util.ArrayList;

public class Estante {
	
	private String nome;
	private ArrayList<Livro> livros;
	private Categoria cat;
	public int contarCiencia;
	
	public String getNome() {
		return nome;
	}
	
	public ArrayList<Livro> getLivros() {
		return livros;
	}
	
	public Categoria getCategoria() {
		return cat;
	}

	public Estante(String nome, Categoria cat) {
		this.nome = nome;
		this.livros = new ArrayList<Livro>();
		this.cat = cat;
	}
	
	public void inserirLivro(Livro livro){
		if(livro!=null)
			livros.add(livro);
		if(this.cat == Categoria.Ciencia)
			contarCiencia += contarCiencia;
			
			
	}
	
	public void removerLivro(Livro livro) {
		if(livros.remove(livro))
			System.out.println(livro.getNome() + "Livro removido");
		if(this.cat == Categoria.Ciencia)
			contarCiencia -= contarCiencia;
		else
			System.out.println("Livro nao encontrado");
		

	}
	
//metodo acrescentado para mostrar dados da estante
	
	public void mostrarInfoEstante() {
		System.out.println("Nome da Estante: " + nome);
		System.out.println("Categoria: " + cat);
		System.out.println("Livros na Estante: " + livros);
		System.out.println(" ");
		for(Livro l: livros)
			l.mostrarInfoLivro();
	}

	public int contarCiencia() {
		return contarCiencia;
	}

//	public ArrayList<String> listarAutores(Categoria cat){
		
			
//		}
	
//	public Livro[] listaFilosofia(){
//		for(Categoria cat: Categoria.Filosofia)
//			livros.mostrarInfoLivro();
//	}
	
	
	
}
