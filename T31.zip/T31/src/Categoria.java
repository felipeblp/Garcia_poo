	public enum Categoria {
		Ciencia, Literatura, Filosofia;
	}

