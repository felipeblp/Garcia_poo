	public enum Categoria {
		ciencia, literatura, filosofia;
	}

