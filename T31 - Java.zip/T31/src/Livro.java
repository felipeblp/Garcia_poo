
public class Livro {

	private String nome,autor;
	private int anoPublicacao;

	public String getNome() {
		return nome;
	}

	public String getAutor() {
		return autor;
	}

	public int getAnoPublicacao() {
		return anoPublicacao;
	}

	public Livro(String nome, String autor, int anoPublicacao) {
		super();
		this.nome = nome;
		this.autor = autor;
		this.anoPublicacao = anoPublicacao;
	}
	
//metodo acrescentado para mostrar dados do livro
	
	public void mostrarInfoLivro() {
		System.out.println("T�tulo: " + this.getNome());
		System.out.println("Autor do livro: " + this.getAutor());
		System.out.println("Publicado em: " + this.getAnoPublicacao());
		System.out.println(" ");
	}
}
