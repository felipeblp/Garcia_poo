import java.util.ArrayList;

public class Estante {
	
	private String nome;
	private ArrayList<Livro> livros = new ArrayList<Livro>();
	private Categoria cat;
	
	
	public String getNome() {
		return nome;
	}
	
	public ArrayList<Livro> getLivros() {
		return livros;
	}
	
	public Categoria getCategoria() {
		return cat;
	}

	public Estante(String nome, Categoria cat, ArrayList<Livro> livros) {
		super();
		this.nome = nome;
		this.livros = livros;
		this.cat = cat;
	}
	
	public void inserirLivro(Livro livro){
		livros.add(livro);
		
			
			
	}
	
	public void removerLivro(Livro livro) {
		livros.remove(livro);
		System.out.println(livro.getNome() + "Livro removido");
		
		

	}
	
//metodo acrescentado para mostrar dados da estante
	
	public void mostrarInfoEstante() {
		System.out.println("Nome da Estante: " + nome);
		System.out.println("Categoria: " + cat);
		System.out.println("Livros na Estante: " + livros);
		System.out.println(" ");
		for(Livro l: livros)
			l.mostrarInfoLivro();
	}




	
	
}
