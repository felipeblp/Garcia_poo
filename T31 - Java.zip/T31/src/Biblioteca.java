import java.util.ArrayList;

public class Biblioteca {

	private String nome;
	private ArrayList<Estante> estantes = new ArrayList<Estante>();
	
	public String getNome() {
		return nome;
	}
	
	public ArrayList<Estante> getEstantes() {
		return estantes;
	}

	public Biblioteca(String nome, ArrayList<Estante> estantes) {
		this.nome = nome;
		this.estantes = estantes;
	}
	
	public void inserirEstante(Estante estante) {
		if(estante!=null)
			estantes.add(estante);
		
	}
	
	public void listarFilosofia() {
		for(Estante e : estantes) {
			if(e.getCategoria().toString() == "Filosofia") {
				System.out.println("//////////////Filosofia////////////////");
				for(Livro l: e.getLivros()) {
					l.mostrarInfoLivro();
				}
				System.out.println("//////////////Filosofia////////////////");
			}	
		}
	}
	
	public void contarCiencia() {
		int contciencia=0;
		for(Estante e : estantes) {
			if(e.getCategoria().toString() == "Ciencia") {
				for(Livro l: e.getLivros()) {
					contciencia++;
				}	
			}	
		}
	}
	
	public void listarTudo() {
		for(Estante e : estantes) {
			switch(e.getCategoria().toString()) {
				case "Ciencia":
					System.out.println("///////////Ciencia////////////");
					for(Livro l: e.getLivros()) {
						l.mostrarInfoLivro();
					}
					System.out.println("///////////Ciencia////////////");					
				break;
				
				case "Literatura":
					System.out.println("///////////Literatura////////////");
					for(Livro l: e.getLivros()) {
						l.mostrarInfoLivro();
					}
					System.out.println("///////////Literatura////////////");					
				break;
				
				case "Filosofia":
					System.out.println("///////////Filosofia////////////");
					for(Livro l: e.getLivros()) {
						l.mostrarInfoLivro();
					}
					System.out.println("///////////Filosofia////////////");					
				break;
				
			}									
		}
	}

	
	public void listarAutores(Categoria cat) {
		for(Estante e : estantes) {
			switch(cat.toString()) {
				case "Ciencia":
					System.out.println("///////////Ciencia////////////");
					for(Livro l: e.getLivros()) {						
						System.out.println("Autor: "+l.getAutor());						
					}
					System.out.println("///////////Ciencia////////////");					
				break;
				
				case "Literatura":
					System.out.println("///////////Literatura////////////");
					for(Livro l: e.getLivros()) {						
						System.out.println("Autor: "+l.getAutor());
					}
					System.out.println("///////////Literatura////////////");					
				break;
				
				case "Filosofia":
					System.out.println("///////////Filosofia////////////");
					for(Livro l: e.getLivros()) {
						System.out.println("Autor: "+l.getAutor());						
					}
					System.out.println("///////////Filosofia////////////");					
				break;
				
			}									
		}
	}

	public void listarLivros(Categoria cat) {
		for(Estante e : estantes) {
			switch(cat.toString()) {
				case "Ciencia":
					System.out.println("///////////Ciencia////////////");
					for(Livro l: e.getLivros()) {						
						System.out.println("Nome: "+l.getNome());						
					}
					System.out.println("///////////Ciencia////////////");					
				break;
				
				case "Literatura":
					System.out.println("///////////Literatura////////////");
					for(Livro l: e.getLivros()) {						
						System.out.println("Nome: "+l.getNome());
					}
					System.out.println("///////////Literatura////////////");					
				break;
				
				case "Filosofia":
					System.out.println("///////////Filosofia////////////");
					for(Livro l: e.getLivros()) {
						System.out.println("Nome: "+l.getNome());					
					}
					System.out.println("///////////Filosofia////////////");					
				break;
				
			}									
		}
	}
	
	
	
}	


