import java.util.Scanner;
import java.util.ArrayList;

public class Principal {

	public static void main(String[] args) {
		ArrayList<Estante> estantes = new ArrayList<Estante>();
		ArrayList<Livro> livros = new ArrayList<Livro>();
		Biblioteca b = new Biblioteca("teste", estantes);
		Estante e;
		Categoria c;
		String nome, autor;
		int ano;
		int cont = 9;
		do {
			Scanner s = new Scanner(System.in);
			
			System.out.println("Ol� usuario, o que deseja fazer? ");
			System.out.println("1 - Inserir Livro na Estante: ");
			System.out.println("2 - Remover Livro da Estante : ");
			System.out.println("3 - Adicionar a Estante a biblioteca: ");
			System.out.println("4 - Listar Categoria Filosofia: ");
			System.out.println("5 - Contar Livros categoria ciencia: ");
			System.out.println("6 - Listar Autores por categoria: ");
			System.out.println("7 - Listar todos os livros de todas as estantes: ");
			System.out.println("0 - Sair: ");	
			int op = s.nextInt();			
			
			switch(op) {
	                case 1:
	                	System.out.println("Digite a categoria do livro: ");
						System.out.println("1-Ciencias: ");
						System.out.println("2-Literatura: ");
						System.out.println("3-Filosofia: ");
						int op2 = s.nextInt();
						switch(op2) {
							case 1:
								c = Categoria.ciencia;
								Estante est = new Estante(nome, c, livros);
								System.out.println("Digite o nome do livro: ");
								nome = s.nextLine();
								System.out.println("Digite o nome do autor: ");
								autor = s.nextLine();
								System.out.println("Digite o ano de publicacao: ");
								ano = s.nextInt();
								Livro l =  new Livro(nome, autor, ano);
														
								break;
							case 2:
								c = Categoria.literatura;
								System.out.println("Digite o nome do livro: ");
								nome = s.nextLine();
								System.out.println("Digite o nome do autor: ");
								autor = s.nextLine();
								System.out.println("Digite o ano de publicacao: ");
								ano = s.nextInt();
								Livro l1 =  new Livro(nome, autor, ano);
								
								break;
							case 3:
								c = Categoria.filosofia;
								System.out.println("Digite o nome do livro: ");
								nome = s.nextLine();
								System.out.println("Digite o nome do autor: ");
								autor = s.nextLine();
								System.out.println("Digite o ano de publicacao: ");
								ano = s.nextInt();
								Livro l2 =  new Livro(nome, autor, ano);
								
								break;
						}		
	                        break;
	                case 2:
	                	System.out.println("Remover Livro: ");
	                	e.removerLivro(livros.getNome());
	                	
	                        break;                
	                case 3:
	                	System.out.println("Adicionar Estante: ");
	                	b.inserirEstante(estantes.getNome());
	                		break;
	                case 4:
	                	System.out.println("Listando categoria Filosofia: ");
	                	b.listarFilosofia();	
	                	break;
	                case 5:
	                	System.out.println("Contando livroscategoria Ciencia: ");
	                	 b.contarCiencia();
	                        break;
	                case 6: 
	                	System.out.println("Listando autores por categoria: ");
	                	b.listarAutores(Categoria.filosofia);	
	                	b.listarAutores(Categoria.ciencia);
	                	b.listarAutores(Categoria.literatura);
	                	break;
	                case 7: 
	                	System.out.println("Listando tudo: ");
	                	b.listarTudo();
                			break;
	                case 0:
	                		System.out.println("Ate Logo!");
	                		break;
	                 
	              default: 
	                       System.out.println("Op��o inv�lida.");
	                       break; }
	                      
	            }
	            
	            while(cont != 0); 
	            
	
	}

}
